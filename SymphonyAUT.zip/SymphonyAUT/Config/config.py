import uuid
from enum import Enum



class TestData:

    def __init__(self):
        pass

    CHROME_EXECUTABLE_PATH = "C:/Symphony/SymphonyAUT-master/SymphonyAUT-master/chromedriver"
    FIREFOX_EXECUTABLE_PATH = "C:/Symphony/SymphonyAUT-master/SymphonyAUT-master/geckodriver"
    IE_EXECUTABLE_PATH = "C:/Symphony/SymphonyAUT-master/SymphonyAUT-master/IEDriverServer"

    BASE_URL = " https://developers.symphony.com"
    USER_NAME = "tuhina2591@gmail.com"
    PASSWORD = "Test@123"
    DIFF_PASSWORD = "Test123@"
    FIRST_NAME = "Garett"
    LAST_NAME = "Smith"
    COUNTRY = "SWEDEN"
    HOME_PAGE_TITLE = 'Symphony Dev Center'
    IC_USER_NAME = "amazon@gmail.com"
    IC_PASSWORD = "Test@123"
    IC_EMAIL_FORMAT = "test.com"
    IC_PASS_FORMAT = "test"

    def create_user_name(self):
        name = uuid.uuid4().hex
        name = name.capitalize()
        email = name[0:6] + '@symphonypotal.com'
        return email
