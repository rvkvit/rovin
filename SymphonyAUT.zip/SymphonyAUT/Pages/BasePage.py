from selenium.common.exceptions import TimeoutException, NoSuchElementException
from selenium.webdriver import ActionChains

from selenium.webdriver.common.by import By

from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

""" This class is the parent of all pages."""
""" It contains all the generic methods and utilities for all the pages """


class BasePage:
    SIGN_IN_BUTTON_HOME = (By.XPATH, "//button[text()='Sign In' and @type='button']")

    def __init__(self, driver):
        self.driver = driver
        # self.action = ActionChains(self.driver)

    def do_click(self, by_locator):
        try:
            WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator)).click()
        except TimeoutException as ex:
            print('Failed to find the element!\n{}'.format(ex))
            raise

    def do_double_click(self, by_locator):
        try:
            element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator)).double_click().perform()
            # self.action.double_click(on_element=element)
        except TimeoutException as ex:
            print('Failed to find the element!\n{}'.format(ex))
            raise


    def enter_data(self, by_locator, text):
        try:
            WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator)).send_keys(text)
        except TimeoutException as ex:
            print('Failed to find the element!\n{}'.format(ex))
            raise

    def get_element_text(self, by_locator):
        try:
            element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
            return element.text
        except TimeoutException as ex:
            print('Failed to find the element!\n{}'.format(ex))
            raise

    def is_visible(self, by_locator):
        try:
            element = WebDriverWait(self.driver, 10).until(EC.visibility_of_element_located(by_locator))
            return bool(element)
        except NoSuchElementException as ex:
            print('Failed to find the element!\n{}'.format(ex))
            raise

    def get_list_elements(self, by_locator):
        try:
            elements = self.driver.find_elements_by_xpath(by_locator)

            value = range(2,len(elements)) if len(elements) > 2 else range(len(elements))
            for i in value:
                try:
                    e_message = elements[i].get_attribute("validationMessage")
                    if (str(e_message).lower().find("please fill") != -1) or (str(e_message).lower().find("please include an") != -1) :
                        empty_field_name = elements[i].get_attribute("name")
                        return e_message, empty_field_name

                except Exception as e:
                    raise
        except NoSuchElementException as ex:
            print('Failed to find the element!\n{}'.format(ex))
            raise

    def is_mandatory(self, name):
        try:
            element = self.driver.find_element_by_name(name)
            message = element.get_attribute("validationMessage")
            return message
        except NoSuchElementException as ex:
            print('Failed to find the element!\n{}'.format(ex))
            raise

    def get_title(self, title):
        try:
            WebDriverWait(self.driver, 10).until(EC.title_is(title))
            return self.driver.title
        except TimeoutException as ex:
            print('Failed to find the element!\n{}'.format(ex))
            raise
