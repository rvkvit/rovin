from enum import Enum

from selenium.webdriver.common.by import By

from SymphonyAUT.Pages.BasePage import BasePage


class ElementType_RP(Enum):
    REGISTER_SUCCESS_MESSAGE = 1
    REGISTER_FAILURE_MESSAGE = 2
    FIELD_MANDOT_MESSAGE = 5
    PAGE_MESSAGE = 6
    PASSWORD_DIFFERENT = 7
    EMAIL_INVALID_MESSAGE = 8


class RegisterPage(BasePage):
    """By Locators ...."""

    PAGE_TEXT = (By.XPATH, "//p[text()='Enter your personal information to register to the Symphony Developer Center:']")
    EMAIL = (By.XPATH, "//input[@id='mui-3' and @type ='email']")
    PASSWORD = (By.XPATH, "//input[@id='mui-4' and @type ='password']")
    REPEAT_PASSWORD = (By.XPATH, "//input[@id='mui-5' and @type ='password']")
    FIRST_NAME = (By.XPATH, "//input[@id='mui-6' and @name='firstName']")
    LAST_NAME = (By.XPATH, "//input[@id='mui-7' and @name='lastName']")
    COUNTRY_DROPDOWN = (By.XPATH, "//div[@aria-labelledby='country-label']")
    COUNTRY_NAME = (By.XPATH,"//li[text()='Austria']")
    COMPANY = (By.XPATH, "//input[@id='mui-8' and @name='company']")
    POLICY_CHECKBOX = (By.XPATH, "//input[@name='policy']")
    ALL_ELEMENTS = ".//input[contains(@id,'mui-')]"
    # NOTIFICATION_CHECKBOX = (By.NAME, "newsletter")
    # NOTIFICATION_CHECKBOX = (By.XPATH, "//input[@name='newsletter']")
    REGISTER_BUTTON = (By.XPATH, "//button[text()='Register' and @type='submit']")
    SUCCESS_MESSAGE = (By.XPATH, "//div[contains(@class, 'MuiAlert-message css-1w0ym84') and text() = 'Registration "
                                 "successful. Please check your email for instructions.']")
    PASSWORD_MISMATCH_MESSAGE = (By.XPATH, "//div[contains(@class, 'MuiAlert-message css-1w0ym84') and text() = 'Your "
                                           "passwords do not match']")
    USER_EXIST_MESSAGE = (By.XPATH, "//div[contains(@class, 'MuiAlert-message css-1w0ym84') and text() ="
                                    " 'Account already exists']")
    VALIDATION_FIELD = "username"

    """constructor of the page class"""
    def __init__(self, driver):
        super().__init__(driver)

    """Page Actions for SIGN IN Page"""

    """Get the Page Title"""
    def get_register_page_title(self, title):
        return self.get_title(title)

    """check the element text"""
    def is_element_present(self, element_type):
        element = None
        if element_type == ElementType_RP.PAGE_MESSAGE:
            element = self.is_visible(self.PAGE_TEXT)
        elif element_type == ElementType_RP.REGISTER_SUCCESS_MESSAGE:
            element = self.is_visible(self.SUCCESS_MESSAGE)
        elif element_type == ElementType_RP.PASSWORD_DIFFERENT:
            element = self.is_visible(self.PASSWORD_MISMATCH_MESSAGE)
        elif element_type == ElementType_RP.REGISTER_FAILURE_MESSAGE:
            element = self.is_visible(self.USER_EXIST_MESSAGE)
        return element

    """get the erorr element and field"""

    def get_message_field(self):
        message, name = self.get_list_elements(self.ALL_ELEMENTS)
        return message, name

    """Register to the application and Success"""
    def do_register(self, user_info, company='TestComp'):
        user_data = user_info

        if user_data['email'] is not None:
            self.enter_data(self.EMAIL, user_data['email'])
        if user_data['password'] is not None:
            self.enter_data(self.PASSWORD, user_data['password'])
        if user_data['repeat_password'] is not None:
            self.enter_data(self.REPEAT_PASSWORD, user_data['repeat_password'])
        if user_data['first_name'] is not None:
            self.enter_data(self.FIRST_NAME, user_data['first_name'])
        if user_data['last_name'] is not None:
            self.enter_data(self.LAST_NAME, user_data['last_name'])
        self.enter_data(self.COMPANY, company)
        self.do_click(self.COUNTRY_DROPDOWN)
        self.do_click(self.COUNTRY_NAME)
        # self.do_double_click(self.NOTIFICATION_CHECKBOX)
        self.do_click(self.REGISTER_BUTTON)
