from enum import Enum

from selenium.webdriver.common.by import By

from SymphonyAUT.Config.config import TestData
from SymphonyAUT.Pages.BasePage import BasePage


class ElementType_SP(Enum):
    SIGN_IN_SUCCESS_MESSAGE = 1
    SIGN_OUT_SUCCESS_MESSAGE = 2
    INVALID_CRED_MESSAGE = 3
    SIGN_IN_POPUP = 4


class SigninPage(BasePage):

    """By Locators ...."""
    EMAIL = (By.XPATH, "//input[@id='mui-1' and @type ='email']")
    PASSWORD = (By.XPATH, "//input[@id='mui-2' and @type ='password']")
    SIGN_IN_BUTTON_POPUP = (By.XPATH, "//button[text()='Sign In' and @type='submit']")
    REGISTER = (By.LINK_TEXT, "Register")
    FORGOT_PASSWORD = (By.LINK_TEXT, "Forgot Password")
    POP_UP_TEXT = (By.XPATH,"//p[text()='Enter your credentials to access the developer center:']")
    WELCOME_MESSAGE = (By.XPATH, "//div[contains(@class, 'MuiAlert-message css-1w0ym84')"
                                 " and text() = 'Login successful']")
    SIGNOUT_MESSAGE = (By.XPATH, "//div[contains(@class, 'MuiAlert-message css-1w0ym84')"
                                 " and text() = 'Logout successful']")
    USER_DROPDOWN = (By.XPATH, "//div[contains(@class,'MuiButtonBase-root MuiAccordionSummary-root MuiAccordionSummary-gutters"
                                  " jss20 css-xglvsw') and @role='button']")
    SIGN_OUT_BUTTON = (By.XPATH,"//button[text()='Sign Out']")
    SIGN_IN_ERROR = (By.XPATH, "//div[contains(@class, 'MuiAlert-message css-1w0ym84')"
                               " and text() = 'Invalid Credentials']")
    ALL_ELEMENTS = ".//input[contains(@id,'mui-')]"
    VALIDATION_FIELD = "username"

    """constructor of the page class"""
    def __init__(self, driver):
        super().__init__(driver)

        self.driver.get(TestData.BASE_URL)

    """Page Actions for SIGN IN Page"""

    """Get the Page Title"""
    def get_signin_page_title(self, title):
        return self.get_title(title)

    """check the element present"""
    def is_element_present(self, element_type):
        element = None
        if element_type == ElementType_SP.SIGN_IN_SUCCESS_MESSAGE:
            element = self.is_visible(self.WELCOME_MESSAGE)
        elif element_type == ElementType_SP.SIGN_OUT_SUCCESS_MESSAGE:
            element = self.is_visible(self.SIGNOUT_MESSAGE)
        elif element_type == ElementType_SP.INVALID_CRED_MESSAGE:
            element = self.is_visible(self.SIGN_IN_ERROR)
        elif element_type == ElementType_SP.SIGN_IN_POPUP:
            element = self.is_visible(self.POP_UP_TEXT)
        return element

    def get_message_field(self):
        message, name = self.get_list_elements(self.ALL_ELEMENTS)
        return message, name

    """SignIn to the application and Success"""
    def do_signin(self, email=None, password=None):
        if email is not None:
            self.enter_data(self.EMAIL, email)
        if password is not None:
            self.enter_data(self.PASSWORD, password)
        self.do_click(self.SIGN_IN_BUTTON_POPUP)

    """SignOut of the application and Success"""
    def do_signout(self):
        self.do_click(self.USER_DROPDOWN)
        self.do_click(self.SIGN_OUT_BUTTON)

