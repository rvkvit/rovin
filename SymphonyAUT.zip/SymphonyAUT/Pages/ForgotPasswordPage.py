from enum import Enum

from selenium.webdriver.common.by import By

from SymphonyAUT.Pages.BasePage import BasePage


class ElementType_FP(Enum):
    EMAIL_SUCCESS_MESSAGE = 1
    EMAIL_NOTEXIST_MESSAGE = 2
    FIELD_MANDOT_MESSAGE = 3
    EMAIL_INVALID_MESSAGE = 4
    PAGE_MESSAGE = 5


class ForgotPasswordPage(BasePage):

    """By Locators ...."""
    EMAIL = (By.XPATH, "//input[@name='email' and @type ='email']")
    SEND_RECOVERY_LINK = (By.XPATH, "//button[text()='Send recovery Link' and @type='submit']")
    PAGE_TEXT = (By.XPATH, "//p[text()=\"We\'ll send a recovery link to the following email address:\"]")
    SUCCESS_MESSAGE = (By.XPATH, "//div[contains(@class, 'MuiAlert-message css-1w0ym84') "
                                 "and text() = 'Please check your email for instructions.']")
    ALL_ELEMENTS = ".//input[contains(@id,'mui-')]"
    VALIDATION_FIELD = "username"

    """constructor of the page class"""

    def __init__(self, driver):
        super().__init__(driver)

        # self.driver.get(TestData.BASE_URL)

    """Page Actions for SIGN IN Page"""

    """Get the Page Title"""
    def get_fp_page_title(self, title):
        return self.get_title(title)

    """check the element present"""

    def is_element_present(self, element_type):
        element = None
        if element_type == ElementType_FP.EMAIL_SUCCESS_MESSAGE:
            element = self.is_visible(self.SUCCESS_MESSAGE)
        elif element_type == ElementType_FP.PAGE_MESSAGE:
            element = self.is_visible(self.PAGE_TEXT)
        return element

    """get the error message and field present"""

    def get_message_field(self):
        message, name = self.get_list_elements(self.ALL_ELEMENTS)
        return message, name

    """SignIn to the application and Success"""

    def do_forgot_password(self, email=None):
        if email is not None:
            self.enter_data(self.EMAIL, email)
        self.do_click(self.SEND_RECOVERY_LINK)