import pytest

from SymphonyAUT.Config.config import TestData
from SymphonyAUT.Pages.RegisterPage import RegisterPage, ElementType_RP
from SymphonyAUT.Tests.test_base import BaseTest
from SymphonyAUT.Pages.SignInPage import SigninPage


class Test_Register(BaseTest):

    """Validate the register page is open!"""

    @pytest.mark.order("first")
    def test_register_open(self):
        self.signPage = SigninPage(self.driver)
        self.registerPage = RegisterPage(self.driver)

        """Opening and asserting the Sign In Pop up window"""
        try:
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_click(self.signPage.REGISTER)
            flag = self.registerPage.is_element_present(ElementType_RP.PAGE_MESSAGE)
            assert flag, f"Expected page not found!"

        except Exception as e:
            print('Failed to open the window!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate registering new and existing user on Portal!"""

    @pytest.mark.order("second")
    @pytest.mark.parametrize('reg_status, exp_message, create_new_user',
                             [(True, ElementType_RP.REGISTER_SUCCESS_MESSAGE, True),
                             (False, ElementType_RP.REGISTER_FAILURE_MESSAGE, False)])
    def test_register(self, reg_status, exp_message, create_new_user):
        self.signPage = SigninPage(self.driver)
        self.registerPage = RegisterPage(self.driver)

        user_data = {
            'password': TestData.PASSWORD,
            'repeat_password': TestData.PASSWORD,
            'first_name': TestData.FIRST_NAME,
            'last_name': TestData.LAST_NAME,
        }

        """Open Register Page and Enter the details"""
        try:

            if create_new_user:
                u_name = TestData().create_user_name()
            else:
                u_name = TestData.USER_NAME

            user_data['email'] = u_name
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_click(self.signPage.REGISTER)
            self.registerPage.do_register(user_data)

            success = self.registerPage.is_element_present(exp_message)
            assert success, f"Expected Message not received!!!"

        except Exception as e:
            print('Failed to perform the operation!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate that invalid email are not allowed!"""

    @pytest.mark.order("third")
    def test_register_invalid_email(self):
        self.signPage = SigninPage(self.driver)
        self.registerPage = RegisterPage(self.driver)

        user_data = {
            'email': TestData.IC_EMAIL_FORMAT,
            'password': TestData.PASSWORD,
            'repeat_password': TestData.PASSWORD,
            'first_name': TestData.FIRST_NAME,
            'last_name': TestData.LAST_NAME,
        }

        try:

            """Open register Page and validate email field"""
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_click(self.signPage.REGISTER)
            self.registerPage.do_register(user_data)

            message, name = self.registerPage.get_message_field()
            assert message == "Please include an \'@\' in the email address. \'{}\' is missing an \'@\'.".format(
                TestData.IC_EMAIL_FORMAT), f"Expected Message not received!!!"
            print(f"The Field '{name.upper()}' is not filled in correct format")

        except Exception as e:
            print('Failed to perform the operation!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate email field is mandatory on register page!"""

    @pytest.mark.order("fourth")
    def test_register_mandatory_field(self):
        self.signPage = SigninPage(self.driver)
        self.registerPage = RegisterPage(self.driver)

        user_data = {
            'email': None,
            'password': TestData.PASSWORD,
            'repeat_password': TestData.PASSWORD,
            'first_name': TestData.FIRST_NAME,
            'last_name': TestData.LAST_NAME,
        }

        try:

            """Open Register Page and validate mandatory field"""
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_click(self.signPage.REGISTER)
            self.registerPage.do_register(user_data)

            message, name = self.registerPage.get_message_field()
            assert message == "Please fill out this field.", f"Expected Message not received!!!"
            print(f"The Field '{name.upper()}' is left blank")

        except Exception as e:
            print('Failed to perform the operation!\n{}'.format(e))
            raise
    """***********************************************************************************************************"""

