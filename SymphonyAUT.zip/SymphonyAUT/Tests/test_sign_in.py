import pytest

from SymphonyAUT.Config.config import TestData
from SymphonyAUT.Pages.ForgotPasswordPage import ForgotPasswordPage
from SymphonyAUT.Pages.RegisterPage import RegisterPage
from SymphonyAUT.Tests.test_base import BaseTest
from SymphonyAUT.Pages.SignInPage import SigninPage, ElementType_SP


class Test_SignIn(BaseTest):

    """Validate the launch of Portal and check the Title!"""

    @pytest.mark.order("first")
    def test_assert_title_present(self):
        self.signPage = SigninPage(self.driver)

        try:
            title = self.signPage.get_title(TestData.HOME_PAGE_TITLE)
            assert title == TestData.HOME_PAGE_TITLE, f"Title Mismatch!!"

        except Exception as e:
            print('Failed to launch the homepage!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate the sign in Pop up window is open!"""

    @pytest.mark.order("second")
    def test_signin_visible(self):
        self.signPage = SigninPage(self.driver)

        """Opening and asserting the Sign In Pop up window"""
        try:
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            flag = self.signPage.is_element_present(ElementType_SP.SIGN_IN_POPUP)
            assert flag, f"Expected window not found!"

        except Exception as e:
            print('Failed to open the window!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate the Signin Funtionality with correct and incorrect Credentials!"""

    @pytest.mark.order("third")
    @pytest.mark.parametrize('sign_in_status, exp_message, user_name, password',[
        (True, ElementType_SP.SIGN_IN_SUCCESS_MESSAGE, TestData.USER_NAME, TestData.PASSWORD),
        (False, ElementType_SP.INVALID_CRED_MESSAGE, TestData.IC_USER_NAME, TestData.IC_PASSWORD)])
    def test_signin_funtionality(self, sign_in_status, exp_message, user_name, password):
        self.signPage = SigninPage(self.driver)

        """Open SignIn Window and Enter the details"""
        try:

            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_signin(user_name, password)

            success = self.signPage.is_element_present(exp_message)
            assert success, f"Expected Message not received!!!"

            if sign_in_status:
                self.signPage.do_signout()
                success = self.signPage.is_element_present(ElementType_SP.SIGN_OUT_SUCCESS_MESSAGE)
                assert success, f"User Logout failed"

        except Exception as e:
            print('Failed to perform the operation!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate email field is mandatory on Signin Popup!"""

    @pytest.mark.order("fourth")
    def test_signin_mandatory_field(self):
        self.signPage = SigninPage(self.driver)
        self.registerPage = RegisterPage(self.driver)
        self.fPPage = ForgotPasswordPage(self.driver)

        try:
            """Open Sign Page and validate mandatory field"""
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_signin(None, TestData.PASSWORD)

            message, name = self.signPage.get_message_field()
            assert message == "Please fill out this field.", f"Expected Message not received!!!"
            print(f"The Field '{name.upper()}' is left blank")

        except Exception as e:
            print('Failed to perform the operation!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate that invalid email are not allowed"""

    @pytest.mark.order("fifth")
    def test_signin_invalid(self):
        self.signPage = SigninPage(self.driver)
        self.registerPage = RegisterPage(self.driver)
        self.fPPage = ForgotPasswordPage(self.driver)

        try:
            """Open Signin Page and validate email field"""
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_signin(TestData.IC_EMAIL_FORMAT, TestData.PASSWORD)

            message, name = self.signPage.get_message_field()
            assert message == "Please include an \'@\' in the email address. \'{}\' is missing an \'@\'.".format(
                TestData.IC_EMAIL_FORMAT), f"Expected Message not received!!!"
            print(f"The Field '{name.upper()}' is not filled in correct format")

        except Exception as e:
            print('Failed to perform the operation!\n{}'.format(e))
            raise

        """**********************************************************************************************************"""

