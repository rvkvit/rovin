import pytest

from SymphonyAUT.Config.config import TestData
from SymphonyAUT.Pages.ForgotPasswordPage import ForgotPasswordPage, ElementType_FP
from SymphonyAUT.Tests.test_base import BaseTest
from SymphonyAUT.Pages.SignInPage import SigninPage


class Test_ForgotPassword(BaseTest):
    """Validate the forgot password page is open!"""

    @pytest.mark.order("first")
    def test_forgot_password_open(self):
        self.signPage = SigninPage(self.driver)
        self.fPPage = ForgotPasswordPage(self.driver)

        """Opening and asserting the Sign In Pop up window"""
        try:
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_click(self.signPage.FORGOT_PASSWORD)
            flag = self.fPPage.is_element_present(ElementType_FP.PAGE_MESSAGE)
            assert flag, f"Expected page not found!"

        except Exception as e:
            print('Failed to open the window!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate the Forgot Password functionality"""

    @pytest.mark.order("second")
    def test_forgot_password(self):
        self.signPage = SigninPage(self.driver)
        self.fPPage = ForgotPasswordPage(self.driver)

        """Open ForgotPassword Page and Enter the details"""
        try:
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_click(self.signPage.FORGOT_PASSWORD)
            self.fPPage.do_forgot_password(TestData.USER_NAME)

            success = self.fPPage.is_element_present(ElementType_FP.EMAIL_SUCCESS_MESSAGE)
            assert success, f"Expected Message not received!!!"

        except Exception as e:
            print('Failed to perform the operation!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate that invalid email are not allowed"""

    @pytest.mark.order("third")
    def test_fp_invalid_email(self):
        self.signPage = SigninPage(self.driver)
        self.fPPage = ForgotPasswordPage(self.driver)

        """Open forgot password Page and validate email field"""
        try:
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_click(self.signPage.FORGOT_PASSWORD)
            self.fPPage.do_forgot_password(TestData.IC_EMAIL_FORMAT)

            message, name = self.fPPage.get_message_field()

            assert message == "Please include an \'@\' in the email address. \'{}\' is missing an \'@\'.".format(
                TestData.IC_EMAIL_FORMAT), f"Expected Message not received!!!"
            print(f"The Field '{name.upper()}' is not filled in correct format")

        except Exception as e:
            print('Failed to perform the operation!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""

    """Validate email field is mandatory on register page!"""

    @pytest.mark.order("fourth")
    def test_fp_mandatory_field(self):
        self.signPage = SigninPage(self.driver)
        self.fPPage = ForgotPasswordPage(self.driver)

        try:

            """Open Forgot Password Page and validate mandatory field"""
            self.signPage.do_click(self.signPage.SIGN_IN_BUTTON_HOME)
            self.signPage.do_click(self.signPage.FORGOT_PASSWORD)
            self.fPPage.do_forgot_password(None)

            message, name = self.fPPage.get_message_field()
            assert message == "Please fill out this field.", f"Expected Message not received!!!"
            print(f"The Field '{name.upper()}' is left blank")

        except Exception as e:
            print('Failed to perform the operation!\n{}'.format(e))
            raise

    """***********************************************************************************************************"""
